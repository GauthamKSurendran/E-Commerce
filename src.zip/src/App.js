import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// 1. Context Providers
import ProductProvider from './context/ProductProvider';
import CartProvider from './context/CartProvider';
import OrderProvider from './context/OrderProvider';
import ReviewProvider from './context/ReviewProvider';
import WishlistProvider from './context/WishlistProvider';

// 2. Components & Layout
import Header from './components/Header';
import Footer from './components/Footer';

// 3. Pages
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetails from './pages/ProductDetails';
import About from './pages/About';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import OrderHistory from './pages/OrderHistory';
import Profile from './pages/Profile';
import Wishlist from './pages/Wishlist';
import Login from './pages/Login'; 
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminUsers from './pages/AdminUsers';

// MISSING PAGES TO ADD:
import OrderSuccess from './pages/OrderSuccess'; // RS7: Order Placement confirmation
import AdminOrders from './pages/AdminOrders';   // RS12: Admin Order Management
import NotFound from './pages/NotFound';         // Professional UX handling

import './App.css';

function App() {
  // Initialize state from localStorage so refreshing doesn't clear the login session [cite: 33]
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem("activeSession");
    return savedUser ? JSON.parse(savedUser) : null;
  });

  // Save session to localStorage on login [cite: 33]
  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem("activeSession", JSON.stringify(userData));
  };

  // Clear session on logout
  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("activeSession");
  };

  return (
    <ProductProvider>
      <OrderProvider>
        <CartProvider>
          <ReviewProvider>
            <WishlistProvider>
              <Router>
                <Header user={user} onLogout={handleLogout} />

                <div className="page-wrapper">
                  <Routes>
                    {/* --- PUBLIC ROUTES --- */}
                    <Route path="/" element={<Home user={user} />} />
                    <Route path="/products" element={<Products user={user} />} />
                    <Route path="/product/:id" element={<ProductDetails user={user} />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/cart" element={<Cart user={user} />} />
                    
                    {/* RS1: User Registration & Login [cite: 33] */}
                    <Route path="/login" element={<Login onLogin={handleLogin} />} />
                    <Route path="/admin/login" element={<AdminLogin onLogin={handleLogin} />} />

                    {/* --- USER PROTECTED ROUTES --- */}
                    {/* RS6 & RS7: Checkout and Placement  */}
                    <Route 
                      path="/checkout" 
                      element={user ? <Checkout user={user} /> : <Navigate to="/login" />} 
                    />
                    <Route 
                      path="/order-success" 
                      element={user ? <OrderSuccess /> : <Navigate to="/login" />} 
                    />
                    <Route 
                      path="/orders" 
                      element={user ? <OrderHistory user={user} /> : <Navigate to="/login" />} 
                    />
                    <Route 
                      path="/profile" 
                      element={user ? <Profile user={user} /> : <Navigate to="/login" />} 
                    />
                    <Route 
                      path="/wishlist" 
                      element={user ? <Wishlist user={user} /> : <Navigate to="/login" />} 
                    />

                    {/* --- ADMIN PROTECTED ROUTES ---  */}
                    <Route 
                      path="/admin/dashboard" 
                      element={user?.isAdmin ? <AdminDashboard user={user} /> : <Navigate to="/admin/login" />} 
                    />
                    <Route 
                      path="/admin/products" 
                      element={user?.isAdmin ? <AdminProducts user={user} /> : <Navigate to="/admin/login" />} 
                    />
                    <Route 
                      path="/admin/users" 
                      element={user?.isAdmin ? <AdminUsers user={user} /> : <Navigate to="/admin/login" />} 
                    />
                    {/* RS12: Admin Order Management Route */}
                    <Route 
                      path="/admin/orders" 
                      element={user?.isAdmin ? <AdminOrders user={user} /> : <Navigate to="/admin/login" />} 
                    />

                    {/* Catch-all: Redirect unknown URLs to NotFound Page */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </div>

                <Footer />
              </Router>
            </WishlistProvider>
          </ReviewProvider>
        </CartProvider>
      </OrderProvider>
    </ProductProvider>
  );
}

export default App;