import React, { createContext, useState, useEffect } from "react";

export const ReviewContext = createContext();

export default function ReviewProvider({ children }) {
  // Initialize state from localStorage to ensure reviews persist
  const [reviews, setReviews] = useState(() => {
    const savedReviews = localStorage.getItem("app_reviews");
    return savedReviews ? JSON.parse(savedReviews) : [];
  });

  // Sync reviews to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("app_reviews", JSON.stringify(reviews));
  }, [reviews]);

  /**
   * Add a review to a product
   * RS13: Review & Rating System (Desirable)
   */
  const addReview = (reviewData) => {
    const { productId, userName, rating, comment } = reviewData;

    // Validation to ensure data integrity
    if (!productId || !rating || !comment.trim()) {
      return false;
    }

    const newReview = {
      id: Date.now(), // Unique identifier
      productId,
      userName: userName || "Anonymous",
      rating: Number(rating),
      comment: comment.trim(),
      date: new Date().toLocaleDateString(),
    };

    setReviews((prev) => [newReview, ...prev]); // Add new reviews to the top
    return true;
  };

  /**
   * Get all reviews for a specific product
   */
  const getProductReviews = (productId) =>
    reviews.filter((r) => String(r.productId) === String(productId));

  /**
   * Calculate average rating for a product
   */
  const getAverageRating = (productId) => {
    const productReviews = getProductReviews(productId);
    if (productReviews.length === 0) return 0;
    const sum = productReviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / productReviews.length).toFixed(1);
  };

  /**
   * Delete a review (Admin feature - RS9)
   */
  const deleteReview = (reviewId) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  return (
    <ReviewContext.Provider
      value={{
        reviews,
        addReview,
        getProductReviews,
        getAverageRating,
        deleteReview,
      }}
    >
      {children}
    </ReviewContext.Provider>
  );
}