import React, { createContext, useState } from "react";

export const CartContext = createContext();

export default function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart((prev) => {
      const exists = prev.find((x) => x.id === product.id);
      if (exists) return prev.map((x) => x.id === product.id ? { ...x, qty: x.qty + 1 } : x);
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const removeFromCart = (id) => setCart(cart.filter((x) => x.id !== id));
  
  const updateQty = (id, q) => q > 0 && setCart(cart.map(x => x.id === id ? {...x, qty: q} : x));

  // ESSENTIAL: clearCart must be defined and included in value
  const clearCart = () => setCart([]);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQty, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}