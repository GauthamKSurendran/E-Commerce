import React, { createContext, useState, useEffect } from "react";

export const OrderContext = createContext();

export default function OrderProvider({ children }) {
  // Initialize from localStorage to ensure Order History (RS8) persists 
  const [orders, setOrders] = useState(() => {
    const savedOrders = localStorage.getItem("app_orders");
    return savedOrders ? JSON.parse(savedOrders) : [];
  });

  // Sync with localStorage whenever orders change
  useEffect(() => {
    localStorage.setItem("app_orders", JSON.stringify(orders));
  }, [orders]);

  // RS7: Place a new order with an auto-generated ID 
  const addOrder = (order) => {
    const newOrder = {
      ...order,
      id: `ORD-${Date.now()}`, // RS7: Auto-generated Unique Order ID 
      status: "Pending",        // RS12: Initial status 
      date: new Date().toLocaleDateString()
    };
    setOrders([newOrder, ...orders]);
    return newOrder.id;
  };

  // RS12: Admin updates order status (Pending, Packed, Shipped, Delivered) 
  const updateStatus = (id, status) => {
    setOrders(orders.map(o => o.id === id ? { ...o, status } : o));
  };

  /**
   * RS18: Return & Refund System
   * Allows customer to initiate return for 'Delivered' items
   */
  const requestReturn = (orderId, reason) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: "Return Requested", returnReason: reason } 
        : order
    ));
  };

  /**
   * RS18 & RS11: Approve Refund & Restock 
   * Finalizes refund and triggers inventory update logic
   */
  const finalizeRefund = (orderId) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: "Refunded" } : order
    ));
    // Note: In your App.js logic, ensure you call ProductProvider to increment stock
  };

  // Admin access to all orders for the dashboard (RS9) 
  const allOrders = orders;

  return (
    <OrderContext.Provider value={{ 
      orders, 
      allOrders, 
      addOrder, 
      updateStatus, 
      requestReturn, 
      finalizeRefund 
    }}>
      {children}
    </OrderContext.Provider>
  );
}