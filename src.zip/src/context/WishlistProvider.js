import React, { createContext, useState } from "react";

export const WishlistContext = createContext();

export default function WishlistProvider({ children }) {
  const [wishlist, setWishlist] = useState([]);

  /**
   * RS13: Add product to wishlist (Desirable)
   */
  const addToWishlist = (product) => {
    const exists = wishlist.find(p => p.id === product.id);
    if (!exists) {
      setWishlist([...wishlist, product]);
    }
  };

  /**
   * Remove product from wishlist
   */
  const removeFromWishlist = (id) => {
    setWishlist(wishlist.filter(p => p.id !== id));
  };

  /**
   * Check if product is in wishlist
   */
  const isInWishlist = (id) => {
    return wishlist.some(p => p.id === id);
  };

  return (
    <WishlistContext.Provider value={{ 
      wishlist, 
      addToWishlist, 
      removeFromWishlist, 
      isInWishlist 
    }}>
      {children}
    </WishlistContext.Provider>
  );
}

