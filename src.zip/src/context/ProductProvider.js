import React, { createContext, useState, useEffect } from "react";

// Create the Context
export const ProductContext = createContext();

/**
 * ProductProvider Component
 * Manages global state including variants (RS17), galleries (RS16), and inventory (RS11).
 */
export default function ProductProvider({ children }) {
  // RS16 & RS17: Enhanced Data with Multi-view Galleries and Fashion Variants
  const initialProducts = [
    {
      id: 1,
      name: "Tailored Wool Overcoat",
      price: 8999,
      category: "Men",
      stock: 12, // RS11: Inventory Level
      sizes: ["S", "M", "L", "XL"],
      colors: ["Black", "Charcoal", "Camel"],
      image: "https://images.pexels.com/photos/1049317/pexels-photo-1049317.jpeg",
      images: [
        "https://images.pexels.com/photos/1049317/pexels-photo-1049317.jpeg",
        "https://images.pexels.com/photos/1049316/pexels-photo-1049316.jpeg",
        "https://images.pexels.com/photos/1049315/pexels-photo-1049315.jpeg"
      ],
      description: "A premium slim-fit overcoat made from responsibly sourced wool."
    },
    {
      id: 2,
      name: "Satin Slip Midi Dress",
      price: 4500,
      category: "Women",
      stock: 8,
      sizes: ["XS", "S", "M", "L"],
      colors: ["Champagne", "Black", "Emerald"],
      image: "https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg",
      images: [
        "https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg",
        "https://images.pexels.com/photos/1126994/pexels-photo-1126994.jpeg"
      ],
      description: "Elegant and versatile satin midi dress with a fluid silhouette."
    },
    {
      id: 3,
      name: "Organic Cotton Junior Hoodie",
      price: 2200,
      category: "Kids",
      stock: 20,
      sizes: ["2T", "3T", "4T", "5T"],
      colors: ["Gray", "Navy", "Olive"],
      image: "https://images.pexels.com/photos/1619697/pexels-photo-1619697.jpeg",
      images: [
        "https://images.pexels.com/photos/1619697/pexels-photo-1619697.jpeg",
        "https://images.pexels.com/photos/1619698/pexels-photo-1619698.jpeg"
      ],
      description: "Ultra-soft hoodie for kids made from 100% organic cotton."
    }
  ];

  // Initialize from localStorage to ensure data persistence
  const [products, setProducts] = useState(() => {
    const savedProducts = localStorage.getItem("app_products");
    return savedProducts ? JSON.parse(savedProducts) : initialProducts;
  });

  // Sync products to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem("app_products", JSON.stringify(products));
  }, [products]);

  /**
   * RS10: Admin Management - Add Product
   */
  const addProduct = (newProduct) => {
    setProducts((prev) => [...prev, { ...newProduct, id: Date.now() }]);
  };

  /**
   * RS10: Admin Management - Delete Product
   */
  const deleteProduct = (id) => {
    setProducts((prev) => prev.filter((product) => product.id !== id));
  };

  /**
   * RS11: Automatic Stock Update
   */
  const updateStock = (productId, quantitySold) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === productId ? { ...p, stock: Math.max(0, p.stock - quantitySold) } : p
      )
    );
  };

  /**
   * RS18: Restock items upon refund
   */
  const restockItem = (productId, quantity) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === productId ? { ...p, stock: p.stock + quantity } : p
      )
    );
  };

  return (
    <ProductContext.Provider 
      value={{ 
        products, 
        setProducts, // CRITICAL: Exported to fix Admin Dashboard runtime errors
        addProduct, 
        deleteProduct, 
        updateStock,
        restockItem 
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}