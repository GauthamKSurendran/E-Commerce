import React, { useContext } from "react";
import { CartContext } from "../context/CartProvider";
import { WishlistContext } from "../context/WishlistProvider";
import { Link, useNavigate } from "react-router-dom";

function ProductCard({ product, user }) {
  const { addToCart } = useContext(CartContext);
  const { addToWishlist, removeFromWishlist, isInWishlist } = useContext(WishlistContext);
  const navigate = useNavigate();

  const isInStock = product.stock > 0;
  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = (e) => {
    e.preventDefault();
    if (!user) {
      alert("Please login to add items to your bag.");
      navigate('/login');
      return;
    }
    if (isInStock) addToCart(product);
  };

  const toggleWishlist = (e) => {
    e.preventDefault();
    if (!user) {
        alert("Please login to use the wishlist.");
        navigate('/login');
        return;
    }
    inWishlist ? removeFromWishlist(product.id) : addToWishlist(product);
  };

  return (
    <div className="card border-0 rounded-0 shadow-sm h-100 product-card-hover position-relative">
      <div className="position-relative overflow-hidden">
        <Link to={`/product/${product.id}`}>
          <img src={product.image} className="card-img-top rounded-0" height="380" style={{ objectFit: "cover" }} alt={product.name} />
        </Link>
        <span className={`position-absolute top-0 end-0 badge rounded-0 m-2 ${isInStock ? 'bg-success' : 'bg-danger'}`}>
          {isInStock ? `${product.stock} in stock` : 'Out of Stock'}
        </span>
        <button className="btn btn-light rounded-pill position-absolute top-0 start-0 m-2 opacity-75" onClick={toggleWishlist}>
          {inWishlist ? '❤️' : '🤍'}
        </button>
        <button 
          className="btn btn-dark w-100 rounded-0 position-absolute bottom-0 start-0 opacity-hover"
          onClick={handleAddToCart}
          disabled={!isInStock}
        >
          {!user ? 'Login to Add' : isInStock ? 'Quick Add +' : 'Out of Stock'}
        </button>
      </div>
      <div className="card-body px-0 pt-3">
        <div className="d-flex justify-content-between">
          <div>
            <h6 className="mb-1 fw-bold">{product.name}</h6>
            <p className="text-muted small">{product.category}</p>
          </div>
          <p className="fw-bold">₹{product.price}</p>
        </div>
      </div>
    </div>
  );
}

export default ProductCard;