import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-white border-top pt-5 pb-4 mt-5">
      <div className="container">
        <div className="row g-4">
          {/* Brand Info */}
          <div className="col-lg-4 col-md-6">
            <h5 className="fw-bold mb-3">FASHION.CO</h5>
            <p className="text-muted small">
              A minimalist clothing store dedicated to quality and timeless style. 
              Designed for Men, Women, and Kids who value simplicity and durability.
            </p>
          </div>

          {/* Navigation Links */}
          <div className="col-lg-2 col-md-6">
            <h6 className="fw-bold text-uppercase small mb-3">Shop</h6>
            <ul className="list-unstyled small">
              <li className="mb-2"><Link to="/products?category=Men" className="text-muted text-decoration-none">Men's Collection</Link></li>
              <li className="mb-2"><Link to="/products?category=Women" className="text-muted text-decoration-none">Women's Collection</Link></li>
              <li className="mb-2"><Link to="/products?category=Kids" className="text-muted text-decoration-none">Kids' Collection</Link></li>
            </ul>
          </div>

          {/* Support Links */}
          <div className="col-lg-2 col-md-6">
            <h6 className="fw-bold text-uppercase small mb-3">Company</h6>
            <ul className="list-unstyled small">
              <li className="mb-2"><Link to="/about" className="text-muted text-decoration-none">About Us</Link></li>
              <li className="mb-2"><Link to="/orders" className="text-muted text-decoration-none">Order Tracking</Link></li>
              <li className="mb-2"><Link to="/admin" className="text-muted text-decoration-none">Admin Portal</Link></li>
            </ul>
          </div>

          {/* Newsletter Section */}
          <div className="col-lg-4 col-md-6">
            <h6 className="fw-bold text-uppercase small mb-3">Stay Updated</h6>
            <div className="input-group mb-3">
              <input type="text" className="form-control rounded-0 border-dark small" placeholder="Email Address" />
              <button className="btn btn-dark rounded-0 px-3 small">JOIN</button>
            </div>
          </div>
        </div>
        
        <hr className="my-4" />
        
        <div className="row align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <p className="text-muted extra-small mb-0">© 2026 FASHION.CO. All rights reserved.</p>
          </div>
          <div className="col-md-6 text-center text-md-end">
            <div className="small text-muted">
              Secure Payment: <span className="ms-2">💳 VISA</span> <span className="ms-2">🅿️ PAYPAL</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;