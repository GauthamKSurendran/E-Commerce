import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../context/CartProvider';

export default function Header({ user, onLogout }) {
  const { cart } = useContext(CartContext);
  const cartCount = cart.reduce((acc, item) => acc + item.qty, 0);

  // State to track which menu is being hovered
  const [activeMenu, setActiveMenu] = useState(null);

  // Mega Menu Data Structure
  const menuData = {
    Men: {
      Topwear: ["T-Shirts", "Casual Shirts", "Formal Shirts", "Jackets", "Suits"],
      Bottomwear: ["Jeans", "Casual Trousers", "Formal Trousers", "Shorts"],
    },
    Women: {
      "Indian & Fusion": ["Kurtas & Suits", "Sarees", "Ethnic Wear", "Lehenga Cholis"],
      Western: ["Dresses", "Tops", "Tshirts", "Jeans", "Jumpsuits"],
    },
    Kids: {
      Boys: ["T-Shirts", "Shirts", "Shorts", "Jeans", "Trousers"],
      Girls: ["Dresses", "Tops", "Tshirts", "Clothing Sets", "Skirts"],
      Infants: ["Bodysuits", "Rompers", "Clothing Sets", "Bottom wear"],
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm p-0">
      <div className="container">
        {/* Brand Link */}
        <Link className="navbar-brand fw-black fs-2 py-3" to="/">
          FASHION<span className="text-muted">.CO</span>
        </Link>
        
        {/* Main Navigation Links */}
        <div className="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul className="navbar-nav gap-1 fw-bold h-100">
            <li className="nav-item">
              <Link className="nav-link py-4 px-3" to="/">HOME</Link>
            </li>

            {/* MEGA MENU CATEGORIES */}
            {Object.keys(menuData).map((category) => (
              <li 
                key={category}
                className="nav-item position-static" // Required for full-width dropdown
                onMouseEnter={() => setActiveMenu(category)}
                onMouseLeave={() => setActiveMenu(null)}
              >
                <Link className="nav-link py-4 px-3" to={`/products?category=${category}`}>
                  {category.toUpperCase()}
                </Link>

                {/* The Mega Dropdown Content */}
                {activeMenu === category && (
                  <div className="mega-menu-dropdown shadow-sm border-top border-bottom">
                    <div className="container py-4">
                      <div className="row">
                        {Object.entries(menuData[category]).map(([section, items]) => (
                          <div className="col-md-2" key={section}>
                            <h6 className="fw-bold text-danger small mb-3">{section.toUpperCase()}</h6>
                            <ul className="list-unstyled">
                              {items.map(item => (
                                <li key={item} className="mb-2">
                                  <Link to={`/products?category=${category}&sub=${item}`} className="text-decoration-none text-dark small menu-item-link">
                                    {item}
                                  </Link>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </li>
            ))}

            <li className="nav-item">
              <Link className="nav-link py-4 px-3" to="/about">ABOUT</Link>
            </li>
          </ul>
        </div>

        {/* Action Icons & Auth Buttons */}
        <div className="d-flex align-items-center gap-4">
          {user && (
            <Link to="/profile" className="text-dark text-decoration-none d-flex flex-column align-items-center">
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z" />
              </svg>
              <span className="small fw-bold d-none d-md-block" style={{fontSize: '0.6rem'}}>PROFILE</span>
            </Link>
          )}

          {user && (
            <Link to="/wishlist" className="text-dark text-decoration-none d-flex flex-column align-items-center">
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l8.72-8.72 1.06-1.06a5.5 5.5 0 000-7.78z" />
              </svg>
              <span className="small fw-bold d-none d-md-block" style={{fontSize: '0.6rem'}}>WISHLIST</span>
            </Link>
          )}

          <Link to="/cart" className="position-relative text-dark text-decoration-none d-flex flex-column align-items-center">
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            <span className="small fw-bold d-none d-md-block" style={{fontSize: '0.6rem'}}>BAG</span>
            {cartCount > 0 && (
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-circle bg-danger" style={{fontSize: '0.5rem', padding: '0.25rem 0.4rem'}}>
                {cartCount}
              </span>
            )}
          </Link>

          {user ? (
            <div className="d-flex align-items-center gap-2">
              {user.isAdmin && (
                <Link to="/admin/dashboard" className="btn btn-outline-danger btn-sm rounded-0 fw-bold px-2" style={{ fontSize: '0.6rem' }}>
                  ADMIN
                </Link>
              )}
              <button onClick={onLogout} className="btn btn-dark btn-sm rounded-0 fw-bold px-2" style={{ fontSize: '0.6rem' }}>
                LOGOUT
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn btn-dark btn-sm rounded-0 fw-bold px-3" style={{ fontSize: '0.7rem' }}>
              LOGIN
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}