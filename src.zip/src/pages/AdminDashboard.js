import React, { useContext, useState, useEffect } from "react";
import { Link } from "react-router-dom"; 
import { ProductContext } from "../context/ProductProvider";
import { OrderContext } from "../context/OrderProvider";

function AdminDashboard({ user }) {
  // Access contexts
  const { products } = useContext(ProductContext);
  const { orders, updateStatus } = useContext(OrderContext);
  
  const [totalUserCount, setTotalUserCount] = useState(0);

  // Sync user count from localStorage
  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    setTotalUserCount(storedUsers.length);
  }, []);

  // ANALYTICS CALCULATIONS
  const totalOrders = orders.length;
  const totalProducts = products.length;
  const totalRevenue = orders.reduce((sum, order) => sum + order.amount, 0);

  return (
    <div className="container mt-5 pt-4">
      {/* Header Section */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold mb-0 text-uppercase tracking-tight">Admin Command Center</h2>
          <p className="text-muted small mb-0">Real-time store metrics and management</p>
        </div>
        <div className="text-end">
          <span className="badge bg-danger rounded-pill px-3 py-2 mb-2 d-inline-block">
            WELCOME, {user?.name?.toUpperCase() || "ADMIN"}
          </span>
          <br />
          <Link to="/" className="btn btn-outline-secondary btn-sm rounded-0">View Storefront</Link>
        </div>
      </div>

      {/* Analytics Summary Bar */}
      <div className="row g-4 mb-5">
        {[
          { label: "TOTAL REVENUE", value: `₹${totalRevenue.toLocaleString()}`, color: "text-success" },
          { label: "REGISTERED USERS", value: totalUserCount },
          { label: "PRODUCT COUNT", value: totalProducts },
          { label: "ACTIVE ORDERS", value: totalOrders }
        ].map((stat, idx) => (
          <div className="col-md-3" key={idx}>
            <div className="card border-0 shadow-sm p-4 bg-white h-100 rounded-0">
              <p className="text-muted small fw-bold mb-1">{stat.label}</p>
              <h3 className={`fw-bold mb-0 ${stat.color || "text-dark"}`}>{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Cards */}
      <div className="row g-4 mb-5">
        <div className="col-lg-6">
          <div className="card p-5 shadow-sm border-0 h-100 bg-dark text-white rounded-0 text-center">
            <h4 className="fw-bold mb-3">Inventory Management</h4>
            <p className="opacity-75 mb-4 text-uppercase small letter-spacing">
              Current Stock: {totalProducts} Items
            </p>
            <Link to="/admin/products" className="btn btn-light py-3 fw-bold rounded-0">
              OPEN PRODUCT CATALOG
            </Link>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="card p-5 shadow-sm border-0 h-100 rounded-0 border-dark text-center">
            <h4 className="fw-bold mb-3 text-dark">User Management</h4>
            <p className="text-muted mb-4 text-uppercase small letter-spacing">
              Total Customers: {totalUserCount} Accounts
            </p>
            <Link to="/admin/users" className="btn btn-dark py-3 fw-bold rounded-0">
              VIEW USER ANALYTICS
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="card p-4 shadow-sm border-0 mb-5 rounded-0 border-top border-4 border-dark">
        <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
           <h4 className="fw-bold mb-0 text-uppercase">Recent Customer Orders</h4>
           <span className="badge bg-light text-dark border">{totalOrders} Orders Total</span>
        </div>
        
        <div className="table-responsive">
          <table className="table align-middle table-hover">
            <thead className="table-light">
              <tr className="small fw-bold text-uppercase">
                <th>Order ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Update Progress</th>
              </tr>
            </thead>
            <tbody>
              {orders.length === 0 ? (
                <tr>
                  <td colSpan="4" className="text-center py-5 text-muted">
                    <div className="py-3">
                      <p className="mb-0">No customer orders found in the system.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                [...orders].reverse().map(order => (
                  <tr key={order.id}>
                    <td className="font-monospace small text-primary fw-bold">
                      {order.id.length > 15 ? `${order.id.substring(0, 15)}...` : order.id}
                    </td>
                    <td className="fw-bold text-dark">₹{order.amount.toLocaleString()}</td>
                    <td>
                      <span className={`badge rounded-pill px-3 py-2 ${
                        order.status === 'Delivered' ? 'bg-success' : 
                        order.status === 'Shipped' ? 'bg-primary' : 
                        order.status === 'Packed' ? 'bg-warning text-dark' : 'bg-info text-dark'
                      }`}>
                        {order.status.toUpperCase()}
                      </span>
                    </td>
                    <td>
                      <select
                        className="form-select form-select-sm rounded-0 border-dark"
                        value={order.status}
                        onChange={(e) => updateStatus(order.id, e.target.value)}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Packed">Packed</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;