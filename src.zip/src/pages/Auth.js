import React, { useState } from 'react';

export default function Auth({ onLogin }) {
  const [isRegistering, setIsRegistering] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(); // Simulates a successful login
  };

  return (
    <div className="d-flex align-items-center justify-content-center vh-100 bg-light">
      <div className="card p-5 shadow-sm border-0 rounded-0" style={{ width: '400px' }}>
        <h2 className="fw-black mb-4 text-center">
          {isRegistering ? 'CREATE ACCOUNT' : 'LOGIN'}
        </h2>
        
        <form onSubmit={handleSubmit}>
          {isRegistering && (
            <div className="mb-3">
              <label className="small fw-bold">FULL NAME</label>
              <input type="text" className="form-control rounded-0" required />
            </div>
          )}
          <div className="mb-3">
            <label className="small fw-bold">EMAIL ADDRESS</label>
            <input type="email" className="form-control rounded-0" required />
          </div>
          <div className="mb-4">
            <label className="small fw-bold">PASSWORD</label>
            <input type="password" className="form-control rounded-0" required />
          </div>
          
          <button type="submit" className="btn btn-dark w-100 py-3 rounded-0 mb-3">
            {isRegistering ? 'REGISTER' : 'SIGN IN'}
          </button>
        </form>

        <p className="text-center small text-muted mb-0">
          {isRegistering ? 'Already have an account?' : 'New to Modernest?'}
          <button 
            className="btn btn-link text-dark fw-bold text-decoration-none p-0 ms-2 small"
            onClick={() => setIsRegistering(!isRegistering)}
          >
            {isRegistering ? 'Login here' : 'Register here'}
          </button>
        </p>
      </div>
    </div>
  );
}