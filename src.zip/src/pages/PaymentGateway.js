import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartProvider';
import { OrderContext } from '../context/OrderProvider';
import { ProductContext } from '../context/ProductProvider';

const PaymentGateway = ({ user }) => {
  const navigate = useNavigate();
  const { cart, totalPrice, clearCart } = useContext(CartContext);
  const { addOrder } = useContext(OrderContext);
  const { updateStock } = useContext(ProductContext);

  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiry: '',
    cvv: '',
    cardName: user?.name || ''
  });

  const [processing, setProcessing] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPaymentData({ ...paymentData, [name]: value });
  };

  const handlePayment = (e) => {
    e.preventDefault();
    setProcessing(true);

    // Simulate Payment Processing delay
    setTimeout(() => {
      // 1. RS7: Create Order Object
      const orderId = addOrder({
        items: cart,
        totalAmount: totalPrice,
        userEmail: user.email,
        status: 'Pending',
        paymentMethod: 'Card'
      });

      // 2. RS11: Update Stock Levels
      cart.forEach(item => {
        updateStock(item.id, item.qty);
      });

      // 3. Clear Cart and Navigate to Success
      clearCart();
      setProcessing(false);
      navigate('/order-success', { state: { orderId } });
    }, 2000);
  };

  return (
    <div className="container py-5 mt-5">
      <div className="row justify-content-center">
        <div className="col-md-5">
          <div className="card shadow-lg border-0 rounded-0 p-4">
            <h4 className="fw-black mb-4 ls-2 text-uppercase">Secure Payment</h4>
            <div className="d-flex justify-content-between mb-4 pb-2 border-bottom">
              <span className="fw-bold">Amount to Pay:</span>
              <span className="fw-black text-danger">₹{totalPrice.toLocaleString()}</span>
            </div>

            <form onSubmit={handlePayment}>
              <div className="mb-3">
                <label className="small fw-bold text-muted mb-1 ls-1">CARDHOLDER NAME</label>
                <input 
                  type="text" 
                  name="cardName"
                  className="form-control rounded-0 border-dark" 
                  value={paymentData.cardName}
                  onChange={handleInputChange}
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="small fw-bold text-muted mb-1 ls-1">CARD NUMBER</label>
                <input 
                  type="text" 
                  name="cardNumber"
                  placeholder="0000 0000 0000 0000"
                  className="form-control rounded-0 border-dark" 
                  maxLength="16"
                  onChange={handleInputChange}
                  required 
                />
              </div>

              <div className="row">
                <div className="col-6 mb-3">
                  <label className="small fw-bold text-muted mb-1 ls-1">EXPIRY</label>
                  <input 
                    type="text" 
                    name="expiry"
                    placeholder="MM/YY"
                    className="form-control rounded-0 border-dark" 
                    onChange={handleInputChange}
                    required 
                  />
                </div>
                <div className="col-6 mb-4">
                  <label className="small fw-bold text-muted mb-1 ls-1">CVV</label>
                  <input 
                    type="password" 
                    name="cvv"
                    placeholder="***"
                    className="form-control rounded-0 border-dark" 
                    maxLength="3"
                    onChange={handleInputChange}
                    required 
                  />
                </div>
              </div>

              <button 
                type="submit" 
                className="btn btn-dark w-100 py-3 fw-bold ls-2"
                disabled={processing}
              >
                {processing ? 'PROCESSING...' : 'CONFIRM ORDER'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentGateway;