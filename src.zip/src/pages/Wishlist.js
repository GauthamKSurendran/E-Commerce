import React, { useContext } from "react";
import { WishlistContext } from "../context/WishlistProvider";
import { CartContext } from "../context/CartProvider";
import ProductCard from "../components/ProductCard";
import { Link } from "react-router-dom";

function Wishlist({ user }) {
  const { wishlist, removeFromWishlist } = useContext(WishlistContext);
  const { addToCart } = useContext(CartContext);

  // Fallback for unauthenticated access
  if (!user) {
    return (
      <div className="container mt-5 pt-5 text-center">
        <h2 className="fw-black text-uppercase tracking-widest">My Wishlist</h2>
        <p className="text-muted mt-3">Please login to view your saved items.</p>
        <Link to="/login" className="btn btn-dark rounded-0 px-5 py-2 mt-2 fw-bold">LOGIN</Link>
      </div>
    );
  }

  // NEW: Function to transfer all items to the cart
  const handleMoveAllToBag = () => {
    if (wishlist.length === 0) return;

    wishlist.forEach((product) => {
      // Only add to cart if the item is in stock
      if (product.stock > 0) {
        addToCart(product);
      }
    });

    // Optional: Clear wishlist after moving items
    // clearWishlist(); 
    alert("All available items have been moved to your bag!");
  };

  return (
    <div className="container mt-5 pt-5 mb-5">
      {/* Header Section */}
      <div className="d-flex justify-content-between align-items-end mb-4 border-bottom pb-2">
        <h2 className="fw-black mb-0 text-uppercase tracking-wider">My Wishlist</h2>
        <div className="d-flex gap-2">
          {wishlist.length > 0 && (
            <button 
              className="btn btn-outline-dark btn-sm rounded-0 fw-bold px-3"
              onClick={handleMoveAllToBag}
            >
              MOVE ALL TO BAG
            </button>
          )}
          <span className="text-muted small ms-2">{wishlist.length} Items</span>
        </div>
      </div>

      {wishlist.length === 0 ? (
        <div className="text-center py-5 border bg-light shadow-sm rounded-0">
          <p className="lead text-muted mb-4">Your wishlist is currently empty.</p>
          <Link to="/products" className="btn btn-dark rounded-0 px-5 py-2 fw-bold">
            CONTINUE BROWSING
          </Link>
        </div>
      ) : (
        <div className="row g-4">
          {wishlist.map((product) => (
            <div className="col-md-3 col-sm-6" key={product.id}>
              <ProductCard product={product} user={user} />
              <button 
                className="btn btn-link text-danger text-decoration-none w-100 mt-2 small fw-bold text-uppercase"
                style={{ fontSize: '0.75rem' }}
                onClick={() => removeFromWishlist(product.id)}
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Wishlist;