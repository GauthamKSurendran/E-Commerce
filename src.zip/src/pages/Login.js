import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login({ onLogin }) {
  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  // Static Admin Credentials
  const adminEmail = "admin@gmail.com";
  const adminPassword = "admin123";

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    // 1. Basic Validation
    if (!form.email || !form.password || (isRegister && !form.name)) {
      setError("All fields are required");
      return;
    }

    // Retrieve registered users from localStorage
    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];

    if (isRegister) {
      // --- REGISTRATION LOGIC ---
      if (form.password !== form.confirmPassword) {
        setError("Passwords do not match");
        return;
      }

      // Check if user already exists
      const userExists = storedUsers.find((u) => u.email === form.email);
      if (userExists) {
        setError("User already exists with this email. Please login.");
        return;
      }

      // Save new user to "database"
      const newUser = {
        name: form.name,
        email: form.email,
        password: form.password,
        isAdmin: false,
      };

      const updatedUsers = [...storedUsers, newUser];
      localStorage.setItem("users", JSON.stringify(updatedUsers));

      alert("Registration Successful!");
      onLogin(newUser); // Log them in immediately after registration
      navigate("/");
    } else {
      // --- LOGIN LOGIC ---

      // A. Check for Admin first
      if (form.email === adminEmail) {
        if (form.password === adminPassword) {
          alert("Admin Login Successful");
          onLogin({ email: form.email, isAdmin: true, name: "Admin" });
          navigate("/admin/dashboard");
        } else {
          setError("Incorrect Admin Password");
        }
        return;
      }

      // B. Check for Regular User (Look for email AND password match)
      const foundUser = storedUsers.find(
        (u) => u.email === form.email && u.password === form.password
      );

      if (foundUser) {
        alert("Login Successful!");
        onLogin(foundUser);
        navigate("/");
      } else {
        setError("Invalid email or password. Please try again.");
      }
    }
  };

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "80vh" }}
    >
      <div
        className="card shadow-lg border-0 p-4"
        style={{ width: "420px", borderRadius: "15px" }}
      >
        {/* LOGIN / REGISTER TOGGLE */}
        <div className="d-flex mb-4 p-1 bg-light rounded-pill">
          <button
            type="button"
            className={`btn w-50 rounded-pill transition-all ${
              !isRegister ? "btn-dark shadow" : "btn-light text-muted"
            }`}
            onClick={() => {
              setIsRegister(false);
              setError("");
            }}
          >
            Login
          </button>
          <button
            type="button"
            className={`btn w-50 rounded-pill transition-all ${
              isRegister ? "btn-dark shadow" : "btn-light text-muted"
            }`}
            onClick={() => {
              setIsRegister(true);
              setError("");
            }}
          >
            Register
          </button>
        </div>

        {error && <div className="alert alert-danger py-2 small text-center">{error}</div>}

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div className="mb-3">
              <label className="small fw-bold mb-1">FULL NAME</label>
              <input
                type="text"
                name="name"
                className="form-control rounded-3"
                placeholder="John Doe"
                value={form.name}
                onChange={handleChange}
              />
            </div>
          )}

          <div className="mb-3">
            <label className="small fw-bold mb-1">EMAIL ADDRESS</label>
            <input
              type="email"
              name="email"
              className="form-control rounded-3"
              placeholder="email@example.com"
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label className="small fw-bold mb-1">PASSWORD</label>
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              className="form-control rounded-3"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
            />
          </div>

          {isRegister && (
            <div className="mb-3">
              <label className="small fw-bold mb-1">CONFIRM PASSWORD</label>
              <input
                type={showPassword ? "text" : "password"}
                name="confirmPassword"
                className="form-control rounded-3"
                placeholder="••••••••"
                value={form.confirmPassword}
                onChange={handleChange}
              />
            </div>
          )}

          <div className="form-check mb-4">
            <input
              type="checkbox"
              className="form-check-input"
              id="showCheck"
              onChange={() => setShowPassword(!showPassword)}
            />
            <label className="form-check-label small text-muted" htmlFor="showCheck">
              Show Password
            </label>
          </div>

          <button type="submit" className="btn btn-dark w-100 py-2 rounded-pill fw-bold">
            {isRegister ? "CREATE ACCOUNT" : "SIGN IN"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;