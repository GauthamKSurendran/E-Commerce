import React, { useContext, useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { ProductContext } from "../context/ProductProvider";
import ProductCard from "../components/ProductCard";

function Products({ user }) {
  const { products } = useContext(ProductContext);
  const location = useLocation();

  // 1. STATE MANAGEMENT (Updated for RS3 and RS17)
  const [category, setCategory] = useState("All");
  const [subCategory, setSubCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [priceRange, setPriceRange] = useState(10000);
  const [selectedSize, setSelectedSize] = useState(""); // RS17
  const [selectedColor, setSelectedColor] = useState(""); // RS17

  // 2. SYNC WITH URL PARAMS
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const categoryQuery = params.get("category");
    const subQuery = params.get("sub");

    if (categoryQuery) setCategory(categoryQuery);
    if (subQuery) {
      setSubCategory(subQuery);
      setSearchTerm("");
    } else {
      setSubCategory("");
    }
  }, [location.search]);

  // 3. UPDATED FILTER LOGIC (Fulfills RS3, RS17)
  const filteredProducts = products.filter((p) => {
    const matchesCategory = category === "All" || p.category === category;
    
    const matchesSub = subCategory 
      ? p.name.toLowerCase().includes(subCategory.toLowerCase()) 
      : true;
    
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPrice = p.price <= priceRange;

    // RS17: Specialized fashion filtering for size and color
    const matchesSize = selectedSize === "" || (p.sizes && p.sizes.includes(selectedSize));
    const matchesColor = selectedColor === "" || (p.colors && p.colors.includes(selectedColor));

    return matchesCategory && matchesSub && matchesSearch && matchesPrice && matchesSize && matchesColor;
  });

  const maxAvailablePrice = products.length > 0 
    ? Math.max(...products.map(p => p.price)) 
    : 10000;

  return (
    <div className="container mt-5 pt-4 page-wrapper">
      <div className="row g-4">
        {/* SIDEBAR FILTERS (RS3 & RS17) */}
        <aside className="col-lg-3">
          <div className="sticky-top" style={{ top: '120px', zIndex: 10 }}>
            <h4 className="fw-black mb-4 ls-2 uppercase">Filters</h4>
            
            {/* Search Input (RS3) */}
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">Keyword</label>
              <input 
                type="text" 
                className="form-control rounded-0 border-dark shadow-none" 
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setSubCategory(""); 
                }} 
              />
            </div>

            {/* Category Filter (RS3) */}
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">Category</label>
              <div className="d-flex flex-column gap-1">
                {["All", "Men", "Women", "Kids"].map(cat => (
                  <button 
                    key={cat} 
                    onClick={() => {
                      setCategory(cat);
                      setSubCategory("");
                    }}
                    className={`btn btn-sm text-start rounded-0 py-2 px-3 fw-bold ${category === cat ? "btn-dark" : "btn-outline-secondary border-0"}`}
                  >
                    {cat.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* RS17: Size Selection Filter */}
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">Size</label>
              <div className="d-flex flex-wrap gap-2">
                {["S", "M", "L", "XL"].map(size => (
                  <button 
                    key={size}
                    onClick={() => setSelectedSize(selectedSize === size ? "" : size)}
                    className={`btn btn-sm rounded-0 border fw-bold ${selectedSize === size ? 'btn-dark' : 'btn-outline-dark'}`}
                    style={{ width: '45px', height: '45px' }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* RS17: Color Selection Filter */}
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">Color</label>
              <select 
                className="form-select rounded-0 border-dark shadow-none"
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
              >
                <option value="">All Colors</option>
                <option value="Black">Black</option>
                <option value="Navy">Navy</option>
                <option value="Gray">Gray</option>
                <option value="Camel">Camel</option>
              </select>
            </div>

            {/* Price Range Filter (RS3) */}
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">
                Max Price: ₹{priceRange.toLocaleString()}
              </label>
              <input 
                type="range" 
                className="form-range custom-range" 
                min="0" 
                max={maxAvailablePrice} 
                step="100"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
              />
            </div>

            <button 
              className="btn btn-link text-dark p-0 small fw-bold text-decoration-none border-bottom border-dark"
              onClick={() => {
                setCategory("All");
                setSubCategory("");
                setSearchTerm("");
                setSelectedSize("");
                setSelectedColor("");
                setPriceRange(maxAvailablePrice);
              }}
            >
              RESET ALL FILTERS
            </button>
          </div>
        </aside>

        {/* PRODUCT GRID (RS2) */}
        <main className="col-lg-9">
          <div className="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
            <h2 className="fw-black mb-0 ls-1">
              {category.toUpperCase()} 
              {subCategory && <span className="text-muted fw-light"> / {subCategory.toUpperCase()}</span>}
            </h2>
            <span className="text-muted small fw-bold ls-1">{filteredProducts.length} ITEMS FOUND</span>
          </div>

          <div className="row g-4">
            {filteredProducts.map(product => (
              <div className="col-md-6 col-lg-4" key={product.id}>
                {/* Product Card fulfills RS2 and RS4 display requirements */}
                <ProductCard product={product} user={user} />
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-5 mt-5">
              <div className="mb-4">
                <i className="bi bi-search display-1 text-muted"></i>
              </div>
              <h3 className="fw-black uppercase ls-1">No matches found</h3>
              <p className="text-muted mb-4">Try adjusting your filters or search terms to find what you're looking for.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default Products;