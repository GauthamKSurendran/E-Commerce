import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// 1. Accept onLogin as a prop
function AdminLogin({ onLogin }) {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    const adminEmail = "admin@gmail.com";
    const adminPassword = "admin123";

    if (!email || !password) {
      setError("Email and password are required");
      return;
    }

    if (email === adminEmail && password === adminPassword) {
      alert("Admin Login Successful!");
      
      // 2. Update the global user state so the Header knows you are an Admin
      onLogin({ email: email, isAdmin: true, name: "Admin" });
      
      navigate("/admin/dashboard");
    } else {
      setError("Invalid Admin Credentials. Please try again.");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: "85vh" }}>
      <div className="card shadow-lg border-0 p-4" style={{ width: "420px", borderRadius: "15px" }}>
        <h3 className="text-center fw-bold mb-2">Admin Login 🔐</h3>
        <p className="text-center text-muted mb-4 small">
          Access the management dashboard
        </p>

        {error && <div className="alert alert-danger py-2 small">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="small fw-bold mb-1">ADMIN EMAIL</label>
            <input
              type="email"
              className="form-control rounded-3"
              placeholder="admin@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="small fw-bold mb-1">PASSWORD</label>
            <input
              type={showPassword ? "text" : "password"}
              className="form-control rounded-3"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div className="form-check mb-4">
            <input
              className="form-check-input"
              type="checkbox"
              id="showPass"
              onChange={() => setShowPassword(!showPassword)}
            />
            <label className="form-check-label small text-muted" htmlFor="showPass">
              Show Password
            </label>
          </div>

          <button className="btn btn-dark w-100 rounded-pill py-2 fw-bold" type="submit">
            LOGIN TO DASHBOARD
          </button>
        </form>

        <div className="mt-4 p-3 bg-light rounded-3 text-center">
            <p className="mb-1 small text-uppercase fw-bold text-muted">Demo Access</p>
            <code className="small text-dark">admin@gmail.com / admin123</code>
        </div>
      </div>
    </div>
  );
}

export default AdminLogin;