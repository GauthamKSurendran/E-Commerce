import React, { useContext } from "react";
import { OrderContext } from "../context/OrderProvider";

export default function OrderHistory() {
  // RS8: Fetching past and current orders 
  const { orders, requestReturn } = useContext(OrderContext);

  const handleReturnAction = (orderId) => {
    const reason = prompt("Please enter the reason for your return (e.g., Wrong size, Damaged):");
    if (reason && reason.trim().length > 0) {
      // RS18: Initiating return request 
      requestReturn(orderId, reason);
      alert("Return request submitted successfully.");
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Delivered': return 'bg-success';
      case 'Return Requested': return 'bg-info text-white';
      case 'Refunded': return 'bg-secondary';
      case 'Shipped': return 'bg-primary';
      default: return 'bg-warning text-dark';
    }
  };

  return (
    <div className="container py-5 mt-5">
      <h2 className="fw-black mb-5 text-uppercase ls-2">Your Order History</h2>
      
      {orders.length === 0 ? (
        <div className="text-center py-5 border bg-light">
          <p className="lead text-muted">You haven't placed any orders yet.</p>
        </div>
      ) : (
        <div className="row g-4">
          {orders.map((order) => (
            <div key={order.id} className="card border-0 shadow-sm rounded-0 mb-4 overflow-hidden">
              {/* Order Header */}
              <div className="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                <div>
                  <span className="text-muted extra-small fw-bold text-uppercase ls-1">Order ID:</span>
                  <span className="fw-black ms-2">{order.id}</span>
                </div>
                <span className={`badge rounded-0 px-3 py-2 ${getStatusBadgeClass(order.status)}`}>
                  {order.status.toUpperCase()}
                </span>
              </div>

              {/* Order Content */}
              <div className="card-body">
                <div className="row">
                  <div className="col-md-8">
                    {order.items.map((item) => (
                      <div key={item.id} className="d-flex align-items-center mb-3">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="border"
                          style={{ width: "60px", height: "70px", objectFit: "cover" }} 
                        />
                        <div className="ms-3">
                          <p className="mb-0 fw-bold small text-uppercase">{item.name}</p>
                          <p className="text-muted extra-small mb-0 ls-1">
                            QTY: {item.qty} | UNIT PRICE: ₹{item.price.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Order Summary & RS18 Action */}
                  <div className="col-md-4 border-start text-end">
                    <p className="text-muted extra-small fw-bold mb-1 text-uppercase">Placed on: {order.date}</p>
                    <h5 className="fw-black mb-3">TOTAL: ₹{order.totalAmount?.toLocaleString() || order.amount?.toLocaleString()}</h5>
                    
                    <div className="mb-3">
                      <p className="extra-small text-muted mb-0 fw-bold text-uppercase">Shipping Address:</p>
                      <p className="small text-muted mb-0">
                        {order.shipping?.city}, {order.shipping?.state}
                      </p>
                    </div>

                    {/* RS18: Return System Logic  */}
                    {order.status === 'Delivered' && (
                      <button 
                        className="btn btn-outline-danger btn-sm rounded-0 fw-bold extra-small px-3 ls-1"
                        onClick={() => handleReturnAction(order.id)}
                      >
                        REQUEST RETURN
                      </button>
                    )}

                    {order.status === 'Return Requested' && (
                      <p className="text-info extra-small fw-bold mt-2 ls-1">
                        RETURN PENDING APPROVAL
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}