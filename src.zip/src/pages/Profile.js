import React, { useState, useEffect, useContext } from "react";
import { OrderContext } from "../context/OrderProvider"; // Import OrderContext

/**
 * Profile Page
 * Handles user profile management, saved addresses, and personal Order History
 */
function Profile() {
  const { orders } = useContext(OrderContext); // Access global orders
  
  const [profile, setProfile] = useState(() => {
    const savedUser = localStorage.getItem("activeSession");
    const user = savedUser ? JSON.parse(savedUser) : null;
    return {
      name: user?.name || "User Name",
      email: user?.email || "user@example.com",
      phone: user?.phone || "",
      addresses: user?.addresses || [
        { id: 1, name: "Home", street: "", city: "", state: "", zip: "" },
      ],
    };
  });

  const [editing, setEditing] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: "", street: "", city: "", state: "", zip: "",
  });

  // Filter orders specifically for this logged-in user
  const myOrders = orders.filter(
    (order) => order.userEmail?.toLowerCase() === profile.email.toLowerCase()
  );

  // Sync profile changes back to localStorage
  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("activeSession"));
    if (savedUser) {
      const updatedUser = { ...savedUser, ...profile };
      localStorage.setItem("activeSession", JSON.stringify(updatedUser));
      
      const allUsers = JSON.parse(localStorage.getItem("users")) || [];
      const updatedAllUsers = allUsers.map(u => 
        u.email === profile.email ? updatedUser : u
      );
      localStorage.setItem("users", JSON.stringify(updatedAllUsers));
    }
  }, [profile]);

  const handleAddressChange = (e) => {
    setNewAddress({ ...newAddress, [e.target.name]: e.target.value });
  };

  const handleAddAddress = (e) => {
    e.preventDefault();
    if (!newAddress.name || !newAddress.city) return;
    setProfile({
      ...profile,
      addresses: [...profile.addresses, { ...newAddress, id: Date.now() }],
    });
    setNewAddress({ name: "", street: "", city: "", state: "", zip: "" });
  };

  const deleteAddress = (id) => {
    setProfile({
      ...profile,
      addresses: profile.addresses.filter((a) => a.id !== id),
    });
  };

  return (
    <div className="container mt-5 mb-5 pt-5">
      <div className="row g-4">
        {/* Left Column - Profile Info */}
        <div className="col-md-4">
          <div className="card shadow-sm border-0 p-4 rounded-0">
            <div className="text-center mb-4">
               <div className="bg-dark text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style={{ width: '80px', height: '80px', fontSize: '2rem' }}>
                {profile.name.charAt(0).toUpperCase()}
              </div>
              <h5 className="fw-bold mb-0 text-uppercase tracking-tight">Account Info</h5>
            </div>

            {!editing ? (
              <>
                <div className="mb-3 border-bottom pb-2">
                  <p className="text-muted small mb-0 fw-bold">NAME</p>
                  <p className="mb-0">{profile.name}</p>
                </div>
                <div className="mb-3 border-bottom pb-2">
                  <p className="text-muted small mb-0 fw-bold">EMAIL</p>
                  <p className="mb-0">{profile.email}</p>
                </div>
                <div className="mb-4 border-bottom pb-2">
                  <p className="text-muted small mb-0 fw-bold">PHONE</p>
                  <p className="mb-0">{profile.phone || "Not provided"}</p>
                </div>
                <button className="btn btn-dark w-100 rounded-0 fw-bold py-2" onClick={() => setEditing(true)}>
                  EDIT PROFILE
                </button>
              </>
            ) : (
              <>
                <div className="mb-3">
                  <label className="small fw-bold text-muted">NAME</label>
                  <input type="text" className="form-control rounded-0" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
                </div>
                <div className="mb-3">
                  <label className="small fw-bold text-muted">PHONE</label>
                  <input type="tel" className="form-control rounded-0" value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} />
                </div>
                <button className="btn btn-success w-100 rounded-0 fw-bold py-2" onClick={() => setEditing(false)}>
                  SAVE CHANGES
                </button>
              </>
            )}
          </div>
        </div>

        {/* Right Column - Addresses & Order History */}
        <div className="col-md-8">
          {/* Saved Addresses Section */}
          <div className="card shadow-sm border-0 p-4 mb-4 rounded-0">
            <h5 className="fw-bold mb-4 text-uppercase tracking-tight">Saved Addresses</h5>
            
            {/* Add New Address Form */}
            <div className="mb-4 p-3 bg-light rounded-0">
              <h6 className="fw-bold mb-3 small text-uppercase">Add New Address</h6>
              <form onSubmit={handleAddAddress} className="row g-2">
                <div className="col-md-6">
                  <input type="text" name="name" className="form-control rounded-0" placeholder="Address Label (e.g., Home)" 
                    value={newAddress.name} onChange={handleAddressChange} required />
                </div>
                <div className="col-md-6">
                  <input type="text" name="street" className="form-control rounded-0" placeholder="Street Address" 
                    value={newAddress.street} onChange={handleAddressChange} required />
                </div>
                <div className="col-md-4">
                  <input type="text" name="city" className="form-control rounded-0" placeholder="City" 
                    value={newAddress.city} onChange={handleAddressChange} required />
                </div>
                <div className="col-md-4">
                  <input type="text" name="state" className="form-control rounded-0" placeholder="State" 
                    value={newAddress.state} onChange={handleAddressChange} required />
                </div>
                <div className="col-md-4">
                  <input type="text" name="zip" className="form-control rounded-0" placeholder="ZIP Code" 
                    value={newAddress.zip} onChange={handleAddressChange} required />
                </div>
                <div className="col-12">
                  <button type="submit" className="btn btn-dark rounded-0 px-4">Add Address</button>
                </div>
              </form>
            </div>
            
            <div className="row g-3">
              {profile.addresses.map((address) => (
                <div key={address.id} className="col-md-6">
                  <div className="border p-3 rounded-0 h-100 position-relative">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <h6 className="fw-bold mb-0 text-uppercase small">{address.name}</h6>
                      <button className="btn btn-sm text-danger p-0" onClick={() => deleteAddress(address.id)}>
                        <small>Delete</small>
                      </button>
                    </div>
                    <p className="mb-1 small">{address.street || "No street provided"}</p>
                    <p className="mb-0 small text-muted">{address.city}, {address.state} {address.zip}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* NEW: PERSONAL ORDER HISTORY SECTION */}
          <div className="card shadow-sm border-0 p-4 rounded-0">
            <h5 className="fw-bold mb-4 text-uppercase tracking-tight">Your Order History</h5>
            {myOrders.length === 0 ? (
              <p className="text-muted text-center py-4">You haven't placed any orders yet.</p>
            ) : (
              <div className="table-responsive">
                <table className="table align-middle">
                  <thead className="table-light small fw-bold">
                    <tr>
                      <th>ORDER ID</th>
                      <th>DATE</th>
                      <th>AMOUNT</th>
                      <th>STATUS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myOrders.map((order) => (
                      <tr key={order.id}>
                        <td className="font-monospace small text-primary fw-bold">#{order.id.substring(0, 8)}</td>
                        <td className="small">{order.date}</td>
                        <td className="fw-bold">₹{order.amount.toLocaleString()}</td>
                        <td>
                          <span className={`badge rounded-0 px-2 py-1 ${order.status === 'Delivered' ? 'bg-success' : 'bg-dark'}`}>
                            {order.status.toUpperCase()}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;