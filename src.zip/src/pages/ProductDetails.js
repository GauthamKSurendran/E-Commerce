import React, { useContext, useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ProductContext } from "../context/ProductProvider";
import { CartContext } from "../context/CartProvider";
import { ReviewContext } from "../context/ReviewProvider";
import ProductCard from "../components/ProductCard";

function ProductDetails({ user }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products } = useContext(ProductContext);
  const { addToCart } = useContext(CartContext);
  const { addReview, getProductReviews, getAverageRating } = useContext(ReviewContext);
  
  const product = products.find(p => String(p.id) === String(id));

  // RS16: State to manage the high-resolution image gallery active view
  const [activeImage, setActiveImage] = useState("");
  const [review, setReview] = useState("");
  const [rating, setRating] = useState(5);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  // RS16: Initialize the gallery with the first available image
  useEffect(() => {
    if (product) {
      setActiveImage(product.images ? product.images[0] : product.image);
      window.scrollTo(0, 0);
    }
  }, [product, id]);

  if (!product) {
    return (
      <div className="container mt-5 pt-5 text-center">
        <h3 className="fw-black">PRODUCT NOT FOUND</h3>
        <button className="btn btn-dark mt-3 rounded-0 px-4" onClick={() => navigate('/products')}>
          BACK TO SHOP
        </button>
      </div>
    );
  }

  // RS4: Fetching product-specific information [cite: 33]
  const productReviews = getProductReviews(product.id);
  const averageRating = getAverageRating(product.id);
  const isInStock = product.stock > 0;

  // RS2 & RS3: Related Products Logic [cite: 33]
  const relatedProducts = products
    .filter(p => p.category === product.category && String(p.id) !== String(id))
    .slice(0, 4);

  // RS5: Add to Cart logic with RS1 Authentication check 
  const handleAddToCart = () => {
    if (!user) {
      alert("Please login to add items to your bag.");
      navigate('/login');
      return;
    }
    if (isInStock) {
      addToCart(product);
      alert(`${product.name} added to bag!`);
    }
  };

  // RS13: Review Submission logic [cite: 34]
  const handleAddReview = (e) => {
    e.preventDefault();
    if (!user) {
      alert("Please login to write a review.");
      navigate('/login');
      return;
    }
    if (!review.trim()) {
      alert("Please share your thoughts in the comments.");
      return;
    }
    
    const success = addReview({
      productId: product.id,
      userName: user.name || user.email.split('@')[0],
      rating: parseInt(rating),
      comment: review
    });
    
    if (success) {
      setReviewSubmitted(true);
      setReview("");
      setRating(5);
      setTimeout(() => setReviewSubmitted(false), 3000);
    }
  };

  return (
    <div className="container mt-5 mb-5 pt-5">
      <div className="row g-5">
        
        {/* RS16: Product Image Gallery Section */}
        <div className="col-md-6">
          <div className="row g-2">
            {/* Main High-Resolution View */}
            <div className="col-12 mb-2">
              <div className="product-image-wrapper border bg-light shadow-sm overflow-hidden">
                <img 
                  src={activeImage} 
                  className="img-fluid w-100 transition-all img-zoom" 
                  alt={product.name}
                  style={{ height: '600px', objectFit: "cover" }}
                />
              </div>
            </div>
            
            {/* RS16: Thumbnail Gallery (Front, Back, Side) */}
            <div className="col-12 d-flex gap-2 overflow-auto pb-2">
              {product.images && product.images.map((img, index) => (
                <div 
                  key={index} 
                  className={`border cursor-pointer transition-all ${activeImage === img ? 'border-dark border-2' : 'opacity-75'}`}
                  onClick={() => setActiveImage(img)}
                  style={{ width: '80px', height: '100px', flexShrink: 0 }}
                >
                  <img src={img} className="w-100 h-100" alt={`View ${index + 1}`} style={{ objectFit: 'cover' }} />
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Product Info Section */}
        <div className="col-md-6">
          <div className="ps-lg-4">
            <h2 className="fw-black mb-1 text-uppercase ls-1">{product.name}</h2>
            <p className="text-muted mb-3 small fw-bold text-uppercase ls-2">{product.category}</p>
            
            <div className="mb-4 d-flex align-items-center">
              <span className="badge bg-dark rounded-0 px-3 py-2 fs-6">
                {averageRating > 0 ? `${averageRating} ⭐` : 'NEW'}
              </span>
              <span className="text-muted ms-3 small fw-bold">({productReviews.length} VERIFIED REVIEWS)</span>
            </div>

            <h3 className="fw-black mb-4 fs-1">₹{product.price.toLocaleString()}</h3>
            
            {/* RS11: Inventory Status [cite: 34] */}
            <p className={`fw-bold mb-4 small text-uppercase ls-1 ${isInStock ? 'text-success' : 'text-danger'}`}>
              {isInStock ? `✓ ${product.stock} Units in stock` : '✗ Currently Out of Stock'}
            </p>

            <p className="mb-5 text-secondary" style={{ fontSize: '1rem', lineHeight: '1.8' }}>
              {product.description}
            </p>

            <button 
              className={`btn w-100 py-3 fw-bold mb-4 rounded-0 ls-2 transition-all ${user ? 'btn-dark' : 'btn-outline-secondary'}`}
              onClick={handleAddToCart}
              disabled={!isInStock}
            >
              {!user ? 'LOGIN TO ADD TO BAG' : isInStock ? 'ADD TO BAG' : 'OUT OF STOCK'}
            </button>
          </div>
        </div>
      </div>

      {/* RS2: Related Products Section [cite: 33] */}
      {relatedProducts.length > 0 && (
        <section className="mt-5 pt-5 border-top">
          <h4 className="fw-black mb-4 text-uppercase ls-2">You May Also Like</h4>
          <div className="row g-4">
            {relatedProducts.map(item => (
              <div className="col-md-3 col-6" key={item.id}>
                <ProductCard product={item} user={user} />
              </div>
            ))}
          </div>
        </section>
      )}

      <hr className="my-5" />

      {/* RS13: Detailed Review Section [cite: 34] */}
      <section className="row mt-5">
        <div className="col-md-8 mx-auto">
          <h4 className="fw-black mb-5 text-uppercase text-center ls-3">Product Feedback</h4>
          
          {reviewSubmitted && (
            <div className="alert alert-success rounded-0 border-0 shadow-sm text-center fw-bold" role="alert">
              ✓ YOUR REVIEW HAS BEEN PUBLISHED
            </div>
          )}

          <div className="card bg-light p-4 mb-5 border-0 rounded-0 shadow-sm">
            <h5 className="fw-black mb-4 small text-uppercase ls-1">Share Your Experience</h5>
            {user ? (
              <form onSubmit={handleAddReview}>
                <div className="mb-3">
                  <label className="form-label fw-bold small text-muted ls-1">POSTING AS</label>
                  <input type="text" className="form-control rounded-0 bg-white border-0" value={user.name || user.email} disabled />
                </div>

                <div className="mb-3">
                  <label className="form-label fw-bold small text-muted ls-1">YOUR RATING</label>
                  <select className="form-select rounded-0 border-0 shadow-sm" value={rating} onChange={(e) => setRating(e.target.value)}>
                    <option value="5">5 Stars - Excellent</option>
                    <option value="4">4 Stars - Very Good</option>
                    <option value="3">3 Stars - Good</option>
                    <option value="2">2 Stars - Fair</option>
                    <option value="1">1 Star - Poor</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="form-label fw-bold small text-muted ls-1">COMMENTS</label>
                  <textarea
                    className="form-control rounded-0 border-0 shadow-sm"
                    rows="4"
                    placeholder="Describe the fit, fabric, and style..."
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                    required
                  />
                </div>

                <button type="submit" className="btn btn-dark rounded-0 px-5 fw-bold ls-1">
                  PUBLISH REVIEW
                </button>
              </form>
            ) : (
              <div className="text-center py-4 bg-white shadow-sm">
                <p className="text-muted fw-bold mb-3 small ls-1">LOGIN REQUIRED TO POST REVIEWS</p>
                <button className="btn btn-outline-dark rounded-0 px-5 fw-bold" onClick={() => navigate('/login')}>
                  LOGIN NOW
                </button>
              </div>
            )}
          </div>

          <div className="mt-5">
            {productReviews.length === 0 ? (
              <div className="text-center py-5 border-top">
                <p className="text-muted ls-1 uppercase small fw-bold">No reviews for this garment yet</p>
              </div>
            ) : (
              <div>
                {productReviews.map((r) => (
                  <div key={r.id} className="border-bottom pb-4 mb-4">
                    <div className="d-flex justify-content-between align-items-start">
                      <div>
                        <h6 className="fw-black mb-1 text-uppercase small ls-1">{r.userName}</h6>
                        <span className="text-warning small">
                           {'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}
                        </span>
                      </div>
                      <span className="text-muted extra-small fw-bold">{r.date}</span>
                    </div>
                    <p className="mt-3 mb-0 text-secondary" style={{ fontSize: '1rem', lineHeight: '1.6' }}>
                      {r.comment}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

export default ProductDetails;