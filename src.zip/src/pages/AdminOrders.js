import React, { useContext } from 'react';
import { OrderContext } from '../context/OrderProvider';
import { ProductContext } from '../context/ProductProvider';

const AdminOrders = () => {
  // RS12 & RS18: Accessing all orders and return/refund management functions
  const { allOrders, updateStatus, finalizeRefund } = useContext(OrderContext);
  const { restockItem } = useContext(ProductContext);

  // Helper for dynamic badge colors including RS18 statuses
  const getStatusClass = (status) => {
    switch (status) {
      case 'Delivered': return 'bg-success';
      case 'Shipped': return 'bg-primary';
      case 'Packed': return 'bg-info';
      case 'Return Requested': return 'bg-danger'; // New for RS18
      case 'Refunded': return 'bg-secondary';       // New for RS18
      case 'Pending': return 'bg-warning text-dark';
      default: return 'bg-secondary';
    }
  };

  const handleStatusChange = (orderId, newStatus) => {
    if (newStatus === "Refunded") {
      // RS11 & RS18: Finalizing refund triggers inventory restock
      const order = allOrders.find(o => o.id === orderId);
      if (order && order.items) {
        order.items.forEach(item => {
          restockItem(item.id, item.qty);
        });
      }
      finalizeRefund(orderId);
    } else {
      updateStatus(orderId, newStatus);
    }
  };

  return (
    <div className="container mt-5 pt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="fw-black m-0">CUSTOMER ORDERS</h2>
        {/* RS31: Basic analytics - total orders count */}
        <span className="badge bg-dark rounded-0 px-3">
          Total Orders: {allOrders.length}
        </span>
      </div>

      {allOrders.length === 0 ? (
        <div className="text-center py-5 border bg-light">
          <p className="text-muted">No customer orders found in the system.</p>
        </div>
      ) : (
        <div className="table-responsive shadow-sm">
          <table className="table table-hover align-middle border">
            <thead className="table-dark">
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Total Amount</th>
                <th>Current Status</th>
                <th className="text-center">Manage Order</th>
              </tr>
            </thead>
            <tbody>
              {allOrders.map((order) => (
                <tr key={order.id}>
                  {/* RS7: Unique auto-generated Order ID Display */}
                  <td className="small fw-bold text-uppercase">{order.id}</td>
                  <td className="small text-muted">{order.date}</td>
                  <td>
                    <div className="small fw-bold">{order.userEmail}</div>
                    {/* Display return reason if RS18 is triggered */}
                    {order.returnReason && (
                      <div className="extra-small text-danger mt-1">
                        Reason: {order.returnReason}
                      </div>
                    )}
                  </td>
                  <td className="fw-bold">₹{order.totalAmount?.toLocaleString()}</td>
                  <td>
                    {/* RS12: Visual status indicator for real-time tracking */}
                    <span className={`badge rounded-0 w-100 py-2 ${getStatusClass(order.status)}`}>
                      {order.status.toUpperCase()}
                    </span>
                  </td>
                  <td>
                    {/* RS12 & RS18: Admin status management dropdown */}
                    <select 
                      className="form-select form-select-sm rounded-0 border-dark"
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Packed">Packed</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Return Requested">Return Requested</option>
                      <option value="Refunded">Refunded</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;