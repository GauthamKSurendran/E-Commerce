import React, { useContext } from "react";
import { CartContext } from "../context/CartProvider";
import { useNavigate } from "react-router-dom";

// Pass 'user' as a prop from App.js
export default function Cart({ user }) {
  const { cart, removeFromCart, updateQty } = useContext(CartContext);
  const navigate = useNavigate();

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.qty, 0);
  const total = subtotal;

  if (cart.length === 0) {
    return (
      <div className="container text-center py-5">
        <h2 className="fw-light mb-4">Your shopping bag is empty.</h2>
        <button className="btn btn-dark rounded-0 px-4" onClick={() => navigate("/products")}>
          CONTINUE SHOPPING
        </button>
      </div>
    );
  }

  return (
    <div className="container py-5">
      <h3 className="fw-bold mb-5">Shopping Bag</h3>
      <div className="row g-5">
        <div className="col-lg-8">
          {cart.map(item => (
            <div key={item.id} className="row border-bottom pb-4 mb-4 align-items-center">
              <div className="col-3 col-md-2">
                <img src={item.image} alt={item.name} className="img-fluid" />
              </div>
              <div className="col-9 col-md-10">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <h6 className="fw-bold mb-1">{item.name}</h6>
                    <p className="text-muted small mb-3">Category: {item.category}</p>
                    <div className="d-flex align-items-center gap-3">
                      <div className="input-group input-group-sm" style={{width: '100px'}}>
                        <button className="btn btn-outline-dark rounded-0" onClick={() => updateQty(item.id, item.qty - 1)}>-</button>
                        <span className="input-group-text bg-white border-dark rounded-0 px-3">{item.qty}</span>
                        <button className="btn btn-outline-dark rounded-0" onClick={() => updateQty(item.id, item.qty + 1)}>+</button>
                      </div>
                      <button className="btn btn-link text-danger p-0 small" onClick={() => removeFromCart(item.id)}>Remove</button>
                    </div>
                  </div>
                  <p className="fw-bold">₹{item.price * item.qty}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* SUMMARY SECTION */}
        <div className="col-lg-4">
          <div className="card border-0 bg-light p-4">
            <h5 className="fw-bold mb-4">Summary</h5>
            <div className="d-flex justify-content-between mb-3">
              <span>Subtotal</span><span>₹{subtotal}</span>
            </div>
            <div className="d-flex justify-content-between mb-4">
              <span>Shipping</span><span className="text-success">Free</span>
            </div>
            <hr />
            <div className="d-flex justify-content-between fw-bold mb-4 fs-5">
              <span>Total</span><span>₹{total}</span>
            </div>

            {/* CONDITIONAL ACTION BUTTON */}
            {user ? (
              /* User is logged in: Show Checkout button */
              <button 
                className="btn btn-dark w-100 py-3 rounded-0 fw-bold" 
                onClick={() => navigate("/checkout")}
              >
                PROCEED TO CHECKOUT
              </button>
            ) : (
              /* User is a guest: Show Login prompt */
              <div className="text-center p-3 border border-dark border-opacity-25 bg-white">
                <p className="small mb-3">Please login to complete your purchase.</p>
                <button 
                  className="btn btn-dark w-100 py-2 rounded-0 fw-bold" 
                  onClick={() => navigate("/login")}
                >
                  LOGIN TO CHECKOUT
                </button>
              </div>
            )}
            
          </div>
        </div>
      </div>
    </div>
  );
}