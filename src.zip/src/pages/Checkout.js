import React, { useState, useContext, useEffect } from "react";
import { CartContext } from "../context/CartProvider";
import { OrderContext } from "../context/OrderProvider";
import { ProductContext } from "../context/ProductProvider";
import { useNavigate } from "react-router-dom";

export default function Checkout({ user }) {
  const { cart, clearCart } = useContext(CartContext);
  const { addOrder } = useContext(OrderContext);
  const { updateStock } = useContext(ProductContext);
  const navigate = useNavigate();

  /**
   * RS6 & RS9: Initialize shipping state
   * Automatically populates from the first saved address if available
   */
  const [shipping, setShipping] = useState({ 
    name: user?.name || '', 
    street: user?.addresses?.[0]?.street || '', 
    city: user?.addresses?.[0]?.city || '', 
    state: user?.addresses?.[0]?.state || '', 
    zip: user?.addresses?.[0]?.zip || '' 
  });

  const [paymentMethod, setPaymentMethod] = useState("card");
  const [upiId, setUpiId] = useState("");

  const total = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  // RS9: Handler to switch between saved addresses
  const handleSelectSavedAddress = (addr) => {
    setShipping({
      name: user.name,
      street: addr.street,
      city: addr.city,
      state: addr.state,
      zip: addr.zip
    });
  };

  const handlePlaceOrder = (e) => {
    e.preventDefault();
    
    // RS6: Validation of mandatory shipping details
    if (!shipping.name || !shipping.street || !shipping.city || !shipping.state || !shipping.zip) {
      alert("Please fill in all shipping details");
      return;
    }

    // RS1: Secure authentication check
    if (!user || !user.email) {
      alert("Please log in to complete your purchase");
      navigate("/login");
      return;
    }

    // Payment Logic Flow
    if (paymentMethod === "card") {
      navigate("/payment-gateway", { state: { shipping, total } });
    } 
    else if (paymentMethod === "upi") {
      if (!upiId.includes("@")) {
        alert("Please enter a valid UPI ID (e.g., name@okaxis)");
        return;
      }
      processFinalOrder("UPI");
    } 
    else {
      processFinalOrder("COD");
    }
  };

  /**
   * Helper to handle RS7 (Order Placement) and RS11 (Inventory Sync)
   */
  const processFinalOrder = (method) => {
    const orderId = `ORD-${Date.now()}`; // RS7: Unique Order ID generation
    
    // RS11: Automatically decrement stock levels based on cart quantity
    cart.forEach(item => {
      updateStock(item.id, item.qty);
    });

    // RS7: Save order record to the global Order History
    addOrder({ 
      id: orderId, 
      userEmail: user.email, 
      items: [...cart], 
      shipping, 
      amount: total, 
      paymentMethod: method,
      status: 'Pending', 
      date: new Date().toLocaleDateString() 
    });
    
    clearCart();
    alert(`Order Placed (${method}) Successfully! ID: ${orderId}`);
    navigate("/orders");
  };

  if (cart.length === 0) return (
    <div className="container py-5 text-center mt-5 page-wrapper">
      <p className="text-muted">Your cart is empty.</p>
      <button className="btn btn-dark rounded-0 px-4" onClick={() => navigate("/products")}>SHOP NOW</button>
    </div>
  );

  return (
    <div className="container py-5 mt-5">
      <div className="row g-5">
        <div className="col-lg-7">
          <h4 className="fw-black text-uppercase ls-2 mb-4 border-bottom pb-2">Shipping & Delivery</h4>
          
          {/* RS9: Selection UI for Saved Addresses */}
          {user?.addresses?.length > 0 && (
            <div className="mb-4">
              <label className="small fw-bold mb-2 text-muted uppercase ls-1">Select Saved Address</label>
              <div className="row g-2">
                {user.addresses.map((addr, index) => (
                  <div key={index} className="col-md-6">
                    <div 
                      className={`card p-3 rounded-0 cursor-pointer border-2 transition-all ${shipping.street === addr.street ? 'border-dark shadow-sm bg-light' : 'border-light'}`}
                      onClick={() => handleSelectSavedAddress(addr)}
                      style={{ cursor: 'pointer' }}
                    >
                      <p className="extra-small fw-bold mb-1 text-uppercase">{addr.label || 'Home'}</p>
                      <p className="small text-muted mb-0">{addr.street}, {addr.city}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <form onSubmit={handlePlaceOrder} className="row g-3">
            <div className="col-12">
              <label className="extra-small fw-bold text-muted uppercase ls-1">Recipient Name</label>
              <input type="text" className="form-control rounded-0 p-3" required 
                value={shipping.name} onChange={e => setShipping({...shipping, name: e.target.value})} />
            </div>
            <div className="col-12">
              <label className="extra-small fw-bold text-muted uppercase ls-1">Street Address</label>
              <input type="text" className="form-control rounded-0 p-3" required 
                value={shipping.street} onChange={e => setShipping({...shipping, street: e.target.value})} />
            </div>
            <div className="col-md-4">
              <label className="extra-small fw-bold text-muted uppercase ls-1">City</label>
              <input type="text" className="form-control rounded-0 p-3" required 
                value={shipping.city} onChange={e => setShipping({...shipping, city: e.target.value})} />
            </div>
            <div className="col-md-4">
              <label className="extra-small fw-bold text-muted uppercase ls-1">State</label>
              <input type="text" className="form-control rounded-0 p-3" required 
                value={shipping.state} onChange={e => setShipping({...shipping, state: e.target.value})} />
            </div>
            <div className="col-md-4">
              <label className="extra-small fw-bold text-muted uppercase ls-1">ZIP</label>
              <input type="text" className="form-control rounded-0 p-3" required 
                value={shipping.zip} onChange={e => setShipping({...shipping, zip: e.target.value})} />
            </div>

            {/* Payment Selection Section */}
            <div className="col-12 mt-4">
              <h4 className="fw-black text-uppercase ls-2 mb-3">Payment Method</h4>
              <div className="list-group rounded-0">
                <label className={`list-group-item d-flex gap-3 py-3 ${paymentMethod === 'card' ? 'bg-light border-dark' : ''}`}>
                  <input className="form-check-input" type="radio" name="payment" checked={paymentMethod === 'card'} onChange={() => setPaymentMethod('card')} />
                  <span className="fw-bold small ls-1 uppercase">Credit / Debit Card</span>
                </label>
                
                <label className={`list-group-item py-3 ${paymentMethod === 'upi' ? 'bg-light border-dark' : ''}`}>
                  <div className="d-flex gap-3 align-items-center mb-2">
                    <input className="form-check-input" type="radio" name="payment" checked={paymentMethod === 'upi'} onChange={() => setPaymentMethod('upi')} />
                    <span className="fw-bold small ls-1 uppercase">UPI Payment</span>
                  </div>
                  {paymentMethod === 'upi' && (
                    <input type="text" className="form-control rounded-0 mt-2 border-dark" placeholder="Enter UPI ID (username@bank)" 
                      value={upiId} onChange={(e) => setUpiId(e.target.value)} required />
                  )}
                </label>

                <label className={`list-group-item d-flex gap-3 py-3 ${paymentMethod === 'cod' ? 'bg-light border-dark' : ''}`}>
                  <input className="form-check-input" type="radio" name="payment" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} />
                  <span className="fw-bold small ls-1 uppercase">Cash on Delivery</span>
                </label>
              </div>
            </div>

            <div className="col-12">
              <button className="btn btn-dark w-100 py-3 mt-4 fw-black ls-2">
                {paymentMethod === 'card' ? 'PROCEED TO CARD PAYMENT' : 'PURCHASE NOW'}
              </button>
            </div>
          </form>
        </div>

        {/* Order Summary */}
        <div className="col-lg-5">
          <div className="bg-light p-4 border border-dark sticky-top" style={{ top: '100px' }}>
             <h5 className="fw-black text-uppercase ls-1 mb-4">Summary</h5>
             <div className="d-flex justify-content-between mb-4 fs-4">
               <span>Total Payable</span>
               <span className="fw-black text-danger">₹{total.toLocaleString()}</span>
             </div>
             <p className="extra-small text-muted text-uppercase fw-bold ls-1">Free delivery & Secure transaction</p>
             <p className="extra-small text-muted mt-2">Taxes calculated at checkout.</p>
          </div>
        </div>
      </div>
    </div>
  );
}