import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { ProductContext } from "../context/ProductProvider";
import ProductCard from "../components/ProductCard";

// FIX: Receive the 'user' prop from App.js to enable login-aware buttons
export default function Home({ user }) {
  const { products } = useContext(ProductContext);

  // Display the first 4 products as "Featured" on the landing page
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="page-wrapper">
      
      {/* 1. HERO SECTION */}
      <section className="position-relative overflow-hidden mb-5" style={{ height: '85vh' }}>
        <img 
          src="/Homebg.png" 
          className="position-absolute w-100 h-100" 
          style={{ objectFit: 'cover' }} 
          alt="New Collection 2026" 
        />
        <div className="position-absolute top-50 start-0 translate-middle-y ps-5 text-white bg-dark bg-opacity-25 p-4 w-100">
          <div className="container">
            <h1 className="display-1 fw-black mb-0">THE WINTER</h1>
            <h1 className="display-1 fw-light mb-4">EDIT. 2026</h1>
            <p className="lead mb-4">Premium apparel for Men, Women & Kids.</p>
            <div className="d-flex gap-3">
              <Link to="/products" className="btn btn-light btn-lg rounded-0 px-5 fw-bold">SHOP NOW</Link>
              <Link to="/about" className="btn btn-outline-light btn-lg rounded-0 px-5 fw-bold">OUR STORY</Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CATEGORY GRID */}
      <div className="container py-5">
        <h2 className="text-center fw-black mb-5 tracking-widest text-uppercase">Browse Collections</h2>
        <div className="row g-4">
          
          {/* Men's Category */}
          <div className="col-md-4">
            <Link to="/products?category=Men" className="text-decoration-none">
              <div className="card border-0 rounded-0 shadow-sm overflow-hidden text-center">
                <img src="https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg" className="w-100" style={{height: '500px', objectFit: 'cover'}} alt="Men" />
                <div className="card-body p-4">
                  <h4 className="fw-bold mb-1">MEN</h4>
                  <p className="text-muted small">Suits, Outerwear & Basics</p>
                </div>
              </div>
            </Link>
          </div>

          {/* Women's Category */}
          <div className="col-md-4">
            <Link to="/products?category=Women" className="text-decoration-none">
              <div className="card border-0 rounded-0 shadow-sm overflow-hidden text-center">
                <img src="https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg" className="w-100" style={{height: '500px', objectFit: 'cover'}} alt="Women" />
                <div className="card-body p-4">
                  <h4 className="fw-bold mb-1">WOMEN</h4>
                  <p className="text-muted small">Dresses, Knits & Accessories</p>
                </div>
              </div>
            </Link>
          </div>

          {/* Kids' Category */}
          <div className="col-md-4">
            <Link to="/products?category=Kids" className="text-decoration-none">
              <div className="card border-0 rounded-0 shadow-sm overflow-hidden text-center">
                <img src="https://images.pexels.com/photos/1619697/pexels-photo-1619697.jpeg" className="w-100" style={{height: '500px', objectFit: 'cover'}} alt="Kids" />
                <div className="card-body p-4">
                  <h4 className="fw-bold mb-1">KIDS</h4>
                  <p className="text-muted small">Organic Cotton & Play-sets</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* 3. NEW SECTION: FEATURED PRODUCTS */}
      {/* This section now uses ProductCard and passes the user prop */}
      <section className="container py-5">
        <div className="d-flex justify-content-between align-items-end mb-4 border-bottom pb-2">
            <h3 className="fw-black mb-0 text-uppercase tracking-wider">Editor's Picks</h3>
            <Link to="/products" className="text-dark fw-bold small">VIEW ALL</Link>
        </div>
        <div className="row g-4">
            {featuredProducts.map(product => (
                <div className="col-md-3" key={product.id}>
                    <ProductCard product={product} user={user} />
                </div>
            ))}
        </div>
      </section>

      {/* 4. PROMOTIONAL FEATURE */}
      <section className="bg-light py-5 mt-5 border-top border-bottom">
        <div className="container py-4 text-center">
          <h6 className="fw-bold ls-3 text-muted mb-3">NEW ARRIVALS EVERY WEEK</h6>
          <h2 className="display-5 fw-bold mb-4">Quality Fabrics. Timeless Styles.</h2>
          <Link to="/products" className="btn btn-dark rounded-0 px-5 py-3">VIEW ALL PRODUCTS</Link>
        </div>
      </section>
    </div>
  );
}