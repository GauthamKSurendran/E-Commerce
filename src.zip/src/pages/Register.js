import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (!form.name || !form.email || !form.password || !form.confirmPassword) {
      setError("All fields are required");
      return;
    }

    // RS1 & AS1: Email validation - ensure valid email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      setError("Please enter a valid email address");
      return;
    }

    if (form.password.length < 6) {
      setError("Password must be at least 6 characters long");
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    // RS1: Store user data (in real app, send to backend)
    const existingUsers = JSON.parse(localStorage.getItem("users") || "[]");
    if (existingUsers.some(u => u.email === form.email)) {
      setError("Email already registered. Please login instead.");
      return;
    }

    // Store new user
    existingUsers.push({
      id: Date.now(),
      name: form.name,
      email: form.email,
      password: form.password,
      createdAt: new Date().toLocaleDateString()
    });
    localStorage.setItem("users", JSON.stringify(existingUsers));

    alert("Registration Successful!");
    navigate("/login");
  };

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "85vh" }}
    >
      <div className="card shadow-lg border-0 p-4" style={{ width: "420px" }}>
        <h3 className="text-center fw-bold mb-2">Create Account 🚀</h3>
        <p className="text-center text-muted mb-4">
          Join Fashion Store today
        </p>

        {error && <div className="alert alert-danger py-2">{error}</div>}

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            className="form-control mb-3"
            placeholder="Full Name"
            value={form.name}
            onChange={handleChange}
          />

          <input
            type="email"
            name="email"
            className="form-control mb-3"
            placeholder="Email Address"
            value={form.email}
            onChange={handleChange}
          />

          <input
            type={showPassword ? "text" : "password"}
            name="password"
            className="form-control mb-3"
            placeholder="Create Password"
            value={form.password}
            onChange={handleChange}
          />

          <input
            type={showPassword ? "text" : "password"}
            name="confirmPassword"
            className="form-control mb-3"
            placeholder="Confirm Password"
            value={form.confirmPassword}
            onChange={handleChange}
          />

          <div className="form-check mb-3">
            <input
              className="form-check-input"
              type="checkbox"
              onChange={() => setShowPassword(!showPassword)}
            />
            <label className="form-check-label">
              Show Password
            </label>
          </div>

          <button className="btn btn-success w-100 rounded-pill">
            Register
          </button>
        </form>

        <p className="text-center mt-3 mb-0">
          Already have an account?{" "}
          <Link to="/login" className="fw-semibold">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
