import { Link, useLocation } from "react-router-dom";

function AdminNavbar() {
  const location = useLocation();

  return (
    <div className="bg-dark py-3 mb-4 shadow-sm">
      <div className="container d-flex justify-content-between align-items-center">
        <h5 className="text-white mb-0 fw-bold">ADMIN PANEL</h5>
        <div className="d-flex gap-4">
          <Link to="/admin/dashboard" className={`text-decoration-none ${location.pathname === '/admin/dashboard' ? 'text-white border-bottom' : 'text-white-50'}`}>
            DASHBOARD
          </Link>
          <Link to="/admin/products" className={`text-decoration-none ${location.pathname === '/admin/products' ? 'text-white border-bottom' : 'text-white-50'}`}>
            PRODUCTS
          </Link>
          <Link to="/admin/users" className={`text-decoration-none ${location.pathname === '/admin/users' ? 'text-white border-bottom' : 'text-white-50'}`}>
            USERS
          </Link>
          <Link to="/" className="text-decoration-none text-danger small fw-bold">
            LOGOUT
          </Link>
        </div>
      </div>
    </div>
  );
}