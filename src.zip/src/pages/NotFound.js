import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="container text-center py-5 mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <h1 className="display-1 fw-black text-danger">404</h1>
          <h2 className="fw-black text-uppercase tracking-widest mb-3">Page Not Found</h2>
          <p className="text-muted mb-4">
            The page you are looking for might have been removed, had its name changed, 
            or is temporarily unavailable.
          </p>
          
          <div className="border-top pt-4">
            <h6 className="fw-bold mb-3 text-uppercase small">Try one of these instead:</h6>
            <div className="d-flex flex-wrap justify-content-center gap-3">
              <Link to="/" className="btn btn-dark rounded-0 px-4 py-2">HOME</Link>
              <Link to="/products" className="btn btn-outline-dark rounded-0 px-4 py-2">SHOP</Link>
              <Link to="/about" className="btn btn-outline-dark rounded-0 px-4 py-2">ABOUT US</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;