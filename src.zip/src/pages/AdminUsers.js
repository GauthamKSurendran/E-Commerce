import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import { OrderContext } from "../context/OrderProvider";

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const { orders } = useContext(OrderContext);
  const [viewingOrders, setViewingOrders] = useState(null);
  const [selectedUserEmail, setSelectedUserEmail] = useState("");

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    setUsers(storedUsers);
  }, []);

  // LINKAGE FIX: Matches user email to order userEmail
  const getUserAnalytics = (email) => {
    const userOrders = orders.filter(o => o.userEmail?.toLowerCase() === email.toLowerCase());
    const spent = userOrders.reduce((sum, o) => sum + o.amount, 0);
    return { count: userOrders.length, spent, history: userOrders };
  };

  return (
    <div className="container mt-5 pt-4">
      <Link to="/admin/dashboard" className="text-decoration-none text-muted small fw-bold">← BACK TO DASHBOARD</Link>
      <h2 className="fw-bold mt-3 mb-4">User Analytics & History</h2>

      <div className="card border-0 shadow-sm rounded-0">
        <table className="table align-middle mb-0">
          <thead className="table-light fw-bold small">
            <tr>
              <th className="ps-4">USER PROFILE</th>
              <th>ORDERS</th>
              <th>TOTAL SPENT</th>
              <th className="text-end pe-4">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, idx) => {
              const stats = getUserAnalytics(user.email);
              return (
                <tr key={idx}>
                  <td className="ps-4">
                    <div className="fw-bold">{user.name}</div>
                    <div className="text-muted small">{user.email}</div>
                  </td>
                  <td>
                    <button className="btn btn-link btn-sm p-0 fw-bold text-dark text-decoration-none" 
                            onClick={() => { setViewingOrders(stats.history); setSelectedUserEmail(user.email); }}>
                      {stats.count} Orders ↓
                    </button>
                  </td>
                  <td className="fw-bold text-success">₹{stats.spent.toLocaleString()}</td>
                  <td className="text-end pe-4">
                    <button className="btn btn-sm btn-outline-dark rounded-0 me-2">Promote</button>
                    <button className="btn btn-sm btn-danger rounded-0">Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* History Drill-down */}
      {viewingOrders && (
        <div className="mt-4 p-4 bg-light border border-dark border-opacity-10">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="fw-bold mb-0">Order Detail for: {selectedUserEmail}</h5>
            <button className="btn-close" onClick={() => setViewingOrders(null)}></button>
          </div>
          <table className="table table-sm bg-white border">
            <thead>
              <tr className="small text-muted"><th>ORDER ID</th><th>DATE</th><th>AMOUNT</th><th>STATUS</th></tr>
            </thead>
            <tbody>
              {viewingOrders.map(o => (
                <tr key={o.id}>
                  <td className="font-monospace small text-primary fw-bold">{o.id}</td>
                  <td>{o.date}</td>
                  <td className="fw-bold">₹{o.amount.toLocaleString()}</td>
                  <td><span className="badge bg-dark text-white">{o.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default AdminUsers;