import React, { useContext, useState } from "react";
import { Link } from "react-router-dom"; // Added for navigation
import { ProductContext } from "../context/ProductProvider";

function AdminProducts() {
  const { products, addProduct, setProducts, deleteProduct } = useContext(ProductContext);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  
  const availableSizes = ["S", "M", "L", "XL", "XXL"];

  const [formData, setFormData] = useState({
    name: "",
    price: "",
    category: "Men",
    stock: "",
    image: null,
    imagePreview: "", 
    description: "",
    sizes: []
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        image: file,
        imagePreview: URL.createObjectURL(file) 
      });
    }
  };

  const toggleSize = (size) => {
    const newSizes = formData.sizes.includes(size)
      ? formData.sizes.filter((s) => s !== size)
      : [...formData.sizes, size];
    setFormData({ ...formData, sizes: newSizes });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const productPayload = {
      ...formData,
      price: Number(formData.price),
      stock: Number(formData.stock),
      image: formData.imagePreview, 
    };

    if (editingId) {
      setProducts(products.map(p => p.id === editingId ? { ...productPayload, id: editingId } : p));
      setEditingId(null);
    } else {
      addProduct({ ...productPayload, id: Date.now(), rating: 0 });
    }

    handleCancel();
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({ name: "", price: "", category: "Men", stock: "", image: null, imagePreview: "", description: "", sizes: [] });
  };

  return (
    <div className="container mt-5 pt-4 mb-5">
      {/* NAVIGATION: Back to Dashboard Link */}
      <div className="mb-3">
        <Link to="/admin/dashboard" className="text-decoration-none text-dark small fw-bold">
          ← BACK TO DASHBOARD
        </Link>
      </div>

      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="fw-bold">Product Management</h2>
        <button className="btn btn-dark rounded-0 px-4" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Close Form" : "+ Add New Product"}
        </button>
      </div>

      {showForm && (
        <div className="card shadow-sm border-0 p-4 mb-5 bg-light rounded-0">
          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              <div className="col-md-6">
                <label className="small fw-bold">PRODUCT NAME</label>
                <input type="text" name="name" className="form-control rounded-0" value={formData.name} onChange={handleChange} required />
              </div>
              <div className="col-md-6">
                <label className="small fw-bold">CATEGORY</label>
                <select name="category" className="form-select rounded-0" value={formData.category} onChange={handleChange}>
                  <option value="Men">Men</option>
                  <option value="Women">Women</option>
                  <option value="Kids">Kids</option>
                </select>
              </div>

              <div className="col-md-3">
                <label className="small fw-bold">PRICE (₹)</label>
                <input type="number" name="price" className="form-control rounded-0" value={formData.price} onChange={handleChange} required />
              </div>
              <div className="col-md-3">
                <label className="small fw-bold">STOCK QTY</label>
                <input type="number" name="stock" className="form-control rounded-0" value={formData.stock} onChange={handleChange} required />
              </div>

              <div className="col-md-6">
                <label className="small fw-bold">PRODUCT IMAGE</label>
                <input type="file" accept="image/*" className="form-control rounded-0" onChange={handleImageChange} />
                {formData.imagePreview && (
                  <img src={formData.imagePreview} alt="Preview" className="mt-2 border" style={{ height: '80px', width: '60px', objectFit: 'cover' }} />
                )}
              </div>

              <div className="col-12">
                <label className="small fw-bold d-block mb-2">AVAILABLE SIZES</label>
                <div className="d-flex gap-2">
                  {availableSizes.map(size => (
                    <button
                      key={size}
                      type="button"
                      className={`btn btn-sm rounded-0 border ${formData.sizes.includes(size) ? 'btn-dark' : 'btn-outline-dark'}`}
                      style={{ width: '45px' }}
                      onClick={() => toggleSize(size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              <div className="col-12 mt-4">
                <button type="submit" className="btn btn-dark rounded-0 px-4 me-2">SAVE PRODUCT</button>
                <button type="button" className="btn btn-outline-secondary rounded-0 px-4" onClick={handleCancel}>CANCEL</button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Product Table */}
      <div className="card border-0 shadow-sm rounded-0">
        <div className="table-responsive">
          <table className="table align-middle mb-0 table-hover">
            <thead className="table-dark">
              <tr className="small text-uppercase">
                <th className="ps-4">Product</th>
                <th>Category</th>
                <th>Price</th>
                <th>Sizes</th>
                <th className="text-end pe-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td className="ps-4">
                    <div className="d-flex align-items-center gap-3">
                      <img src={p.image} alt="" className="border" style={{ width: '40px', height: '50px', objectFit: 'cover' }} />
                      <span className="fw-bold">{p.name}</span>
                    </div>
                  </td>
                  <td>{p.category}</td>
                  <td className="fw-bold">₹{p.price.toLocaleString()}</td>
                  <td>
                    {p.sizes?.map(s => <span key={s} className="badge bg-light text-dark border me-1 rounded-0">{s}</span>)}
                  </td>
                  <td className="text-end pe-4">
                    <button className="btn btn-sm btn-outline-dark me-2 rounded-0" onClick={() => { setEditingId(p.id); setFormData({ ...p, imagePreview: p.image }); setShowForm(true); }}>Edit</button>
                    <button className="btn btn-sm btn-danger rounded-0" onClick={() => deleteProduct(p.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default AdminProducts;