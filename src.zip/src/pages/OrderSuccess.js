import React from 'react';
import { Link, useLocation, Navigate } from 'react-router-dom';

const OrderSuccess = ({ user }) => {
  const location = useLocation();
  
  // Retrieve the order ID passed from the Checkout component via state
  const { orderId } = location.state || {};

  // RS8: If no user is logged in or no order data exists, redirect to Home 
  if (!user || !orderId) {
    return <Navigate to="/" />;
  }

  return (
    <div className="container py-5 mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6 text-center">
          <div className="card shadow-hover border-0 rounded-0 p-5">
            {/* Success Icon */}
            <div className="mb-4 text-success">
              <svg width="64" height="64" fill="currentColor" viewBox="0 0 16 16">
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
              </svg>
            </div>

            <h2 className="fw-black text-uppercase ls-2">Order Confirmed!</h2>
            <p className="text-muted mb-4">
              Thank you for your purchase. We've received your order and are getting it ready.
            </p>

            {/* RS7: Auto-generated Order ID display  */}
            <div className="bg-light p-3 mb-4 border border-dashed">
              <p className="small text-muted mb-1 text-uppercase fw-bold">Order Number</p>
              <h4 className="fw-black text-danger m-0">#{orderId}</h4>
            </div>

            <p className="small text-muted mb-4">
              A confirmation email has been sent to <br />
              <span className="fw-bold text-dark">{user.email}</span>
            </p>

            <div className="d-grid gap-2">
              {/* RS8: Link to view order history  */}
              <Link to="/orders" className="btn btn-dark py-3 rounded-0 fw-bold ls-1">
                TRACK MY ORDER
              </Link>
              <Link to="/products" className="btn btn-outline-dark py-3 rounded-0 fw-bold ls-1">
                CONTINUE SHOPPING
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;